package com.prad.pythairstudio.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
