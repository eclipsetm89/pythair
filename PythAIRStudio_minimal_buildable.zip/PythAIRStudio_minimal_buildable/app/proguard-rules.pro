# Minimal project: keep defaults only.
