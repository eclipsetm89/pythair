from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Any

TOKEN_PATTERN = re.compile(r'"(?:\\.|[^"\\])*"|#[^\n]*|[A-Za-z_][A-Za-z0-9_]*|\d+\.\d+|\d+|==|!=|<=|>=|->|=>|[\[\]\(\)\{\}:,=+\-*/.]')
KEYWORDS = {
    "APP", "WINDOW", "LABEL", "BUTTON", "INPUT", "STATUS", "OPEN", "SET",
    "PRINT", "LET", "USE", "STYLE", "ICON", "MENU", "END", "SECTION",
    "TRUE", "FALSE", "NULL"
}

@dataclass
class AirToken:
    kind: str
    value: str
    line: int
    col: int

@dataclass
class AirNode:
    node_type: str
    line: int
    data: dict[str, Any]

class AirParserError(Exception):
    pass

class AirLexer:
    def tokenize(self, text: str) -> list[AirToken]:
        tokens: list[AirToken] = []
        for line_no, line in enumerate(text.splitlines(), start=1):
            for match in TOKEN_PATTERN.finditer(line):
                raw = match.group(0)
                if raw.startswith("#"):
                    break
                col = match.start() + 1
                tokens.append(AirToken(kind=self._classify(raw), value=raw, line=line_no, col=col))
        return tokens

    def _classify(self, raw: str) -> str:
        if raw.startswith('"') and raw.endswith('"'):
            return "STRING"
        if raw in {"[", "]", "(", ")", "{", "}", ":", ",", "=", "+", "-", "*", "/", ".", "==", "!=", "<=", ">=", "->", "=>"}:
            return "SYMBOL"
        if re.fullmatch(r"\d+\.\d+", raw):
            return "FLOAT"
        if re.fullmatch(r"\d+", raw):
            return "INT"
        if raw.upper() in KEYWORDS:
            return "KEYWORD"
        return "IDENT"

class AirParser:
    def parse(self, tokens: list[AirToken]) -> list[AirNode]:
        lines: dict[int, list[AirToken]] = {}
        for tok in tokens:
            lines.setdefault(tok.line, []).append(tok)

        nodes: list[AirNode] = []
        for line_no in sorted(lines):
            toks = lines[line_no]
            if not toks:
                continue
            head = toks[0].value.upper()

            if head == "APP":
                self._expect_count(toks, 2, "APP")
                nodes.append(AirNode("app", toks[0].line, {"name": self._strip_value(toks[1])}))
            elif head in {"WINDOW", "LABEL", "BUTTON", "INPUT", "STATUS", "STYLE", "ICON", "MENU", "SECTION"}:
                self._expect_count(toks, 3, head)
                nodes.append(AirNode(head.lower(), toks[0].line, {
                    "name": self._strip_value(toks[1]),
                    "value": self._strip_value(toks[2]),
                }))
            elif head in {"PRINT", "OPEN"}:
                self._expect_count(toks, 2, head)
                nodes.append(AirNode(head.lower(), toks[0].line, {"value": self._strip_value(toks[1])}))
            elif head == "USE":
                self._expect_count(toks, 2, "USE")
                nodes.append(AirNode("use", toks[0].line, {"name": self._strip_value(toks[1])}))
            elif head == "LET":
                self._expect_min_count(toks, 4, "LET")
                if toks[2].value != "=":
                    raise AirParserError(f"LET missing '=' at line {toks[0].line}")
                nodes.append(AirNode("let", toks[0].line, {
                    "name": self._strip_value(toks[1]),
                    "value": self._strip_value(toks[3]),
                }))
            elif head == "SET":
                self._expect_min_count(toks, 4, "SET")
                if toks[2].value != "=":
                    raise AirParserError(f"SET missing '=' at line {toks[0].line}")
                nodes.append(AirNode("set", toks[0].line, {
                    "target": self._strip_value(toks[1]),
                    "value": self._strip_value(toks[3]),
                }))
            elif head == "END":
                nodes.append(AirNode("end", toks[0].line, {}))
            else:
                raise AirParserError(f"Unknown AIR statement '{toks[0].value}' at line {toks[0].line}, col {toks[0].col}")
        return nodes

    def _expect_count(self, toks: list[AirToken], expected: int, name: str):
        if len(toks) != expected:
            raise AirParserError(f"{name} expects {expected - 1} argument(s) at line {toks[0].line}")

    def _expect_min_count(self, toks: list[AirToken], expected_min: int, name: str):
        if len(toks) < expected_min:
            raise AirParserError(f"{name} expects at least {expected_min - 1} token(s) at line {toks[0].line}")

    def _strip_value(self, tok: AirToken) -> Any:
        raw = tok.value
        if tok.kind == "STRING":
            return bytes(raw[1:-1], "utf-8").decode("unicode_escape")
        if tok.kind == "INT":
            return int(raw)
        if tok.kind == "FLOAT":
            return float(raw)
        if raw.upper() == "TRUE":
            return True
        if raw.upper() == "FALSE":
            return False
        if raw.upper() == "NULL":
            return None
        return raw

class AirValidator:
    UI_NODE_TYPES = {"window", "label", "button", "input", "status", "style", "icon", "menu", "section"}

    def validate(self, nodes: list[AirNode]) -> dict[str, Any]:
        app_count = 0
        declared_objects: set[str] = set()
        declared_vars: set[str] = set()
        errors: list[str] = []
        warnings: list[str] = []

        for node in nodes:
            if node.node_type == "app":
                app_count += 1
                if app_count > 1:
                    errors.append(f"Multiple APP declarations. Line {node.line}.")
            elif node.node_type in self.UI_NODE_TYPES:
                name = str(node.data.get("name", "")).strip()
                if not name:
                    errors.append(f"Missing object name for {node.node_type} at line {node.line}.")
                elif name in declared_objects:
                    errors.append(f"Duplicate object name '{name}' at line {node.line}.")
                else:
                    declared_objects.add(name)
            elif node.node_type == "let":
                name = str(node.data.get("name", "")).strip()
                if not name:
                    errors.append(f"Missing variable name for LET at line {node.line}.")
                elif name in declared_vars:
                    warnings.append(f"Variable '{name}' redefined at line {node.line}.")
                declared_vars.add(name)
            elif node.node_type == "set":
                target = str(node.data.get("target", "")).strip()
                if target not in declared_objects and target not in declared_vars:
                    errors.append(f"SET target '{target}' is not declared before line {node.line}.")

        return {
            "ok": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "stats": {
                "node_count": len(nodes),
                "object_count": len(declared_objects),
                "variable_count": len(declared_vars),
                "app_count": app_count,
            },
        }

class AirLanguageUpdate1:
    def __init__(self) -> None:
        self.lexer = AirLexer()
        self.parser = AirParser()
        self.validator = AirValidator()

    def compile(self, text: str) -> dict[str, Any]:
        tokens = self.lexer.tokenize(text)
        nodes = self.parser.parse(tokens)
        validation = self.validator.validate(nodes)
        return {
            "tokens": [asdict(t) for t in tokens],
            "ast": [asdict(n) for n in nodes],
            "validation": validation,
        }
