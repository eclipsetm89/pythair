package com.prad.pythairstudio

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.BorderStroke
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.prad.pythairstudio.ui.theme.PythAIRStudioTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PythAIRStudioTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    StudioApp()
                }
            }
        }
    }
}

data class PreviewNode(
    val type: String,
    val name: String?,
    val text: String?,
    val action: String?,
    val children: List<PreviewNode>
)

@Composable
fun StudioApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var currentTab by remember { mutableIntStateOf(0) }
    var language by remember { mutableStateOf("python") }
    var editorText by remember { mutableStateOf(defaultPythonDemo()) }
    var output by remember { mutableStateOf("Ready.") }
    var validation by remember { mutableStateOf("No validation yet.") }
    var previewRoot by remember { mutableStateOf<PreviewNode?>(null) }
    val files = remember { mutableStateListOf<String>() }
    var browserUrl by remember { mutableStateOf("https://www.google.com") }
    var browserCommand by remember { mutableStateOf("https://www.google.com") }

    LaunchedEffect(Unit) {
        files.clear()
        files.addAll(PythonBridge.listProjectFiles(context))
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF08111F))
                    .padding(top = 18.dp, start = 12.dp, end = 12.dp, bottom = 10.dp)
            ) {
                Text("PythAIR Studio", color = Color.White, fontSize = 22.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChip("Python", language == "python") {
                        language = "python"
                        editorText = defaultPythonDemo()
                    }
                    ModeChip("PythAIR", language == "pythair") {
                        language = "pythair"
                        editorText = defaultPythairDemo()
                    }
                    ModeChip("AIR", language == "air") {
                        language = "air"
                        editorText = defaultAirDemo()
                    }
                }
            }
        },
        bottomBar = {
            TabRow(selectedTabIndex = currentTab) {
                listOf("Editor", "Preview", "Browser", "Files").forEachIndexed { index, title ->
                    Tab(selected = currentTab == index, onClick = { currentTab = index }, text = { Text(title) })
                }
            }
        }
    ) { padding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0B1220))
        ) {
            when (currentTab) {
                0 -> {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(12.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                scope.launch {
                                    val result = withContext(Dispatchers.Default) {
                                        when (language) {
                                            "python" -> PythonBridge.runPython(editorText)
                                            "pythair" -> PythonBridge.compilePythair(editorText)
                                            else -> PythonBridge.compileAir(editorText)
                                        }
                                    }
                                    output = result.output
                                    validation = result.validation
                                    previewRoot = result.previewJson?.let { parsePreviewNode(JSONObject(it)) }
                                    result.browserUrl?.let {
                                        browserCommand = it
                                        browserUrl = it
                                    }
                                    currentTab = when {
                                        result.browserUrl != null -> 2
                                        result.previewJson != null -> 1
                                        else -> 0
                                    }
                                }
                            }) { Text("Run") }
                            Button(onClick = {
                                scope.launch {
                                    val filename = when (language) {
                                        "python" -> "main.py"
                                        "pythair" -> "main.pythair"
                                        else -> "main.air"
                                    }
                                    PythonBridge.saveProjectFile(context, filename, editorText)
                                    files.clear()
                                    files.addAll(PythonBridge.listProjectFiles(context))
                                    output = "Saved $filename"
                                }
                            }) { Text("Save") }
                            TextButton(onClick = {
                                editorText = when (language) {
                                    "python" -> defaultPythonDemo()
                                    "pythair" -> defaultPythairDemo()
                                    else -> defaultAirDemo()
                                }
                            }) { Text("Load Demo") }
                        }
                        Spacer(Modifier.height(10.dp))
                        EditorPanel(editorText) { editorText = it }
                        Spacer(Modifier.height(10.dp))
                        OutputPanel(title = "Validation", text = validation, modifier = Modifier.weight(0.32f))
                        Spacer(Modifier.height(10.dp))
                        OutputPanel(title = "Output", text = output, modifier = Modifier.weight(0.36f))
                    }
                }
                1 -> PreviewTab(previewRoot)
                2 -> BrowserTab(browserCommand, browserUrl) { browserUrl = it }
                3 -> {
                    FilesPanel(
                        files = files,
                        onOpen = { name ->
                            scope.launch {
                                val loaded = PythonBridge.loadProjectFile(context, name)
                                if (loaded != null) {
                                    editorText = loaded
                                    language = when {
                                        name.endsWith(".py") -> "python"
                                        name.endsWith(".air") -> "air"
                                        else -> "pythair"
                                    }
                                    currentTab = 0
                                    output = "Opened $name"
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun PreviewTab(previewRoot: PreviewNode?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Text("Live Preview", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(10.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10192B)),
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(18.dp)
        ) {
            if (previewRoot == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Run a PythAIR script to see preview.", color = Color(0xFFD7E6FF))
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    RenderPreview(previewRoot)
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BrowserTab(command: String, currentUrl: String, onUrlChanged: (String) -> Unit) {
    var address by remember(command) { mutableStateOf(command) }
    var goSignal by remember(command) { mutableStateOf(command) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Text("Browser · backend=$BROWSER_BACKEND", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(6.dp))
        Text("Current: $currentUrl", color = Color(0xFFBFDBFE), fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, Color(0xFF30435F), RoundedCornerShape(16.dp))
                    .background(Color(0xFF0D1524), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                BasicTextField(
                    value = address,
                    onValueChange = { address = it },
                    textStyle = TextStyle(
                        color = Color(0xFFF8FBFF),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Button(onClick = { goSignal = normalizeUrl(address) }) { Text("Open") }
        }
        Spacer(Modifier.height(10.dp))
        when (BROWSER_BACKEND) {
            "android_webview" -> Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF10192B)),
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(18.dp)
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    url?.let(onUrlChanged)
                                }
                            }
                            webChromeClient = WebChromeClient()
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = true
                            settings.cacheMode = WebSettings.LOAD_DEFAULT
                            loadUrl(normalizeUrl(command))
                        }
                    },
                    update = { webView ->
                        val target = normalizeUrl(goSignal)
                        if (target != webView.url) {
                            webView.loadUrl(target)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            else -> Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF10192B)),
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(18.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Backend '$BROWSER_BACKEND' is declared but not implemented in this starter yet.",
                        color = Color(0xFFD7E6FF),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.border(
            BorderStroke(1.dp, if (selected) Color(0xFF60A5FA) else Color(0xFF30435F)),
            RoundedCornerShape(999.dp)
        )
    ) {
        Text(text, color = if (selected) Color(0xFFBFDBFE) else Color(0xFFCBD5E1))
    }
}

@Composable
private fun EditorPanel(value: String, onValueChange: (String) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .border(1.dp, Color(0xFF30435F), RoundedCornerShape(18.dp))
            .background(Color(0xFF0D1524), RoundedCornerShape(18.dp))
            .padding(12.dp)
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            textStyle = TextStyle(
                color = Color(0xFFF8FBFF),
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                lineHeight = 20.sp
            ),
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .horizontalScroll(rememberScrollState())
        )
    }
}

@Composable
private fun OutputPanel(title: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF30435F), RoundedCornerShape(18.dp))
            .background(Color(0xFF10192B), RoundedCornerShape(18.dp))
            .padding(12.dp)
    ) {
        Text(title, color = Color.White, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            text = text,
            color = Color(0xFFD7E6FF),
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            modifier = Modifier.verticalScroll(rememberScrollState())
        )
    }
}

@Composable
private fun FilesPanel(files: List<String>, onOpen: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Text("Project Files", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(10.dp))
        Column(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, Color(0xFF30435F), RoundedCornerShape(18.dp))
                .background(Color(0xFF10192B), RoundedCornerShape(18.dp))
                .padding(12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (files.isEmpty()) {
                Text("No saved files yet.", color = Color(0xFFD7E6FF))
            }
            files.forEach { name ->
                Card(
                    onClick = { onOpen(name) },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF16233A))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(Color(0xFF60A5FA), RoundedCornerShape(999.dp))
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(name, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun RenderPreview(node: PreviewNode) {
    when (node.type) {
        "window", "col", "root" -> {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                node.text?.takeIf { it.isNotBlank() }?.let {
                    Text(it, color = Color.White, fontSize = 18.sp)
                }
                node.children.forEach { RenderPreview(it) }
            }
        }
        "row" -> {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                node.children.forEach { RenderPreview(it) }
            }
        }
        "txt" -> Text(node.text ?: "", color = Color.White, fontSize = 16.sp)
        "inp" -> Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF30435F), RoundedCornerShape(14.dp))
                .background(Color(0xFF0D1524), RoundedCornerShape(14.dp))
                .padding(12.dp)
        ) {
            Text(node.text ?: "", color = Color(0xFFE2E8F0), fontFamily = FontFamily.Monospace)
        }
        "box" -> Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF16233A)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                node.text?.let { Text(it, color = Color.White, fontSize = 16.sp) }
                node.children.forEach { RenderPreview(it) }
            }
        }
        "bar" -> Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Text(node.text ?: "", color = Color(0xFFE2E8F0))
        }
        "btn" -> Button(onClick = {}) { Text(node.text ?: node.name ?: "Button") }
        else -> Text("Unsupported node: ${node.type}", color = Color(0xFFFCA5A5))
    }
}

private fun parsePreviewNode(obj: JSONObject): PreviewNode {
    val childrenArray = obj.optJSONArray("children") ?: JSONArray()
    val children = buildList {
        for (i in 0 until childrenArray.length()) {
            add(parsePreviewNode(childrenArray.getJSONObject(i)))
        }
    }
    return PreviewNode(
        type = obj.optString("type", "unknown"),
        name = obj.optString("name").ifBlank { null },
        text = obj.optString("text").ifBlank { null },
        action = obj.optString("action").ifBlank { null },
        children = children
    )
}

private fun normalizeUrl(raw: String): String {
    val trimmed = raw.trim()
    if (trimmed.isBlank()) return "https://www.google.com"
    return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed else "https://$trimmed"
}

private fun defaultPythonDemo(): String = """
print("Hello from embedded Python")
for i in range(3):
    print("count", i)
""".trimIndent()

private fun defaultPythairDemo(): String = """
app "Browser Demo"
win main "PythAIR Browser"
col
row
btn back "←"
btn forward "→"
btn reload "⟳"
inp url "https://www.wikipedia.org"
btn open "Open"
bar status "Ready"

browser.open "https://www.wikipedia.org"
""".trimIndent()

private fun defaultAirDemo(): String = """
APP DemoApp
WINDOW main "AIR Window"
LABEL title "Hello AIR"
BUTTON open_btn "Open"
INPUT search_box "type here"
STATUS state_bar "Ready"
OPEN "https://chatgpt.com"
""".trimIndent()
