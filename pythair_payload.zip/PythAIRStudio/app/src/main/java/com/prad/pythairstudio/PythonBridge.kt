package com.prad.pythairstudio

import android.content.Context
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

data class ScriptResult(
    val output: String,
    val validation: String,
    val previewJson: String?,
    val browserUrl: String?
)

object PythonBridge {
    private fun py(context: Context? = null): Python {
        if (!Python.isStarted()) {
            requireNotNull(context) { "Context required for first Python startup" }
            Python.start(AndroidPlatform(context.applicationContext))
        }
        return Python.getInstance()
    }

    private fun module(context: Context? = null): PyObject = py(context).getModule("runtime_api")

    fun runPython(source: String): ScriptResult {
        val result = module().callAttr("run_python", source)
        return parseResult(result)
    }

    fun compilePythair(source: String): ScriptResult {
        val result = module().callAttr("run_pythair", source)
        return parseResult(result)
    }

    fun compileAir(source: String): ScriptResult {
        val result = module().callAttr("run_air", source)
        return parseResult(result)
    }

    fun listProjectFiles(context: Context): List<String> {
        val filesDir = File(context.filesDir, "projects")
        if (!filesDir.exists()) filesDir.mkdirs()
        return filesDir.listFiles()?.sortedBy { it.name.lowercase() }?.map { it.name } ?: emptyList()
    }

    fun saveProjectFile(context: Context, name: String, content: String) {
        val filesDir = File(context.filesDir, "projects")
        if (!filesDir.exists()) filesDir.mkdirs()
        File(filesDir, name).writeText(content)
    }

    fun loadProjectFile(context: Context, name: String): String? {
        val file = File(File(context.filesDir, "projects"), name)
        return if (file.exists()) file.readText() else null
    }

    private fun parseResult(result: PyObject): ScriptResult {
        val output = result.callAttr("get", "output").toString()
        val validation = result.callAttr("get", "validation").toString()
        val preview = result.callAttr("get", "preview_json")
        val browser = result.callAttr("get", "browser_url")
        return ScriptResult(
            output = output,
            validation = validation,
            previewJson = preview.takeIf { !it.isNone() }?.toString(),
            browserUrl = browser.takeIf { !it.isNone() }?.toString()
        )
    }
}
