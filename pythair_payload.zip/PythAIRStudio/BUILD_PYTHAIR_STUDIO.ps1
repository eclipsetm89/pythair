param(
    [string]$ProjectDir = $PSScriptRoot
)

$ErrorActionPreference = "Stop"
Set-Location $ProjectDir

Write-Host "== PythAIR Studio build helper ==" -ForegroundColor Cyan

if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
    Write-Host "Gradle is not on PATH. Open this project in Android Studio and let it sync, or install Gradle first." -ForegroundColor Yellow
    exit 1
}

if (-not (Test-Path ".\gradlew.bat")) {
    Write-Host "Generating Gradle wrapper..." -ForegroundColor Cyan
    gradle wrapper
}

Write-Host "Building debug APK..." -ForegroundColor Cyan
.\gradlew.bat assembleDebug

Write-Host "Done. APK should be under app\build\outputs\apk\debug\" -ForegroundColor Green
